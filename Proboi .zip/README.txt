BYBIT LONG BREAKOUT — GitHub Pages PWA

Что внутри:
- long-only spot scanner;
- минимум оборота $200M (можно менять в интерфейсе);
- 15m / 1h / 1D;
- уровни по swing-high + кластерам касаний;
- состояния APPROACH / COIL / BREAKOUT / RETEST-HOLD;
- volume ratio, compression, multi-timeframe confirmation;
- BTC correlation + простой relative-strength признак decoupling;
- live ticker через публичный Bybit WebSocket;
- iPhone PWA: Add to Home Screen → Open as Web App.

Установка:
1. Создай публичный GitHub repository, например bybit-long-breakout.
2. Загрузи ВСЕ файлы из этой папки в корень репозитория.
3. GitHub → Settings → Pages → Build and deployment → Source: Deploy from a branch.
4. Branch: main, Folder: /(root), Save.
5. Открой появившийся https://USERNAME.github.io/bybit-long-breakout/
6. На iPhone Safari: Share → Add to Home Screen → включи Open as Web App → Add.

Важно:
- GitHub Pages — статический хостинг. Исторические свечи берутся из публичного Bybit REST API, live ticker — через публичный WebSocket.
- Если сеть/регион блокирует api.bybit.com или stream.bybit.com, терминал не сможет получить данные без отдельного backend/proxy.
- Score — технический фильтр, не гарантия пробоя.
- Это long-only скринер, без автоматической торговли и без API-ключей.
